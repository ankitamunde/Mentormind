package com.dbconfig;

public class Databaseconfig {
	public static final String URL = "jdbc:mysql://localhost:3306/practoanpc7699vikasg";
    public static final String USERNAME = "root";
    public static final String PASSWORD = "root"; 
}
