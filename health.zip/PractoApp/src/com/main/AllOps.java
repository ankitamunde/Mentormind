package com.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.dbconfig.Databaseconfig;
import com.user.User;

public class AllOps {
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		boolean b = true;
		try {
			Connection con = DriverManager.getConnection(Databaseconfig.URL, Databaseconfig.USERNAME,
					Databaseconfig.PASSWORD);
			PreparedStatement ad_log = con.prepareStatement("select * from admin where a_email=? and e_pass=?");
			PreparedStatement user_log = con.prepareStatement("select * from userdetails where u_email=? and u_pass=?");
			while (b) {
				System.out.println("**************Welcome to Practo App********");
				System.out.println();
				System.out.println("***    Choice    ***");
				System.out.println("\t1.Register\n\t2.Login\n\t3.Exit");
				System.out.println();
				System.out.println("Enter your choice:---> ");
				System.out.println();
				int choice = scn.nextInt();

				switch (choice) {
				case 1:
					System.out.println("*******Welcome To User Registration*******");
					User user = new User();
					int k = user.registerUser();
					if (k > 0) {
						System.out.println("User Registered Successfully!!!!");
					} else {
						System.out.println("Something went wrong!!! please try again");
					}
					break;
				case 2:
					System.out.println("Welcome To Login Section:");
					   boolean flag=true;
					   while(flag) {
						   System.out.println("\t1.Admin Login\n\t2.User login");
						   System.out.println();
						   System.out.println("Enter your choice:---->");
						   int c= scn.nextInt();
						   switch(c) {
						     case 1:
						    	 break;
						     case 2:
						    	 System.out.println("Welcome user login");
						    	 System.out.println("Enter your email:");
						    	 String email=scn.nextLine();
						    	 scn.nextLine();
						    	 System.out.println("Enter your pass:");
						    	 String pass=scn.nextLine();
						    	 user_log.setString(1, email);
						    	 user_log.setString(2, pass);
						    	 ResultSet rs=user_log.executeQuery();
						    	 if(rs.next()) {
						    		 System.out.println("Login Success!!"+rs.getString(1));
						    	 }else {
						    		 System.out.println("Invalid");
						    	 }
						   }
				
				}  
			}
			}
						   			   
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		}
	}

			
		


		
	
