package com.user;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import com.dbconfig.Databaseconfig;

public class User {

	private int k = 0;

	public int registerUser() {
		try {
			Connection con = DriverManager.getConnection(Databaseconfig.URL, Databaseconfig.USERNAME,
					Databaseconfig.PASSWORD);
			Scanner sc = new Scanner(System.in);
			PreparedStatement pstmt = con.prepareStatement("insert into userdetails values(?,?,?,?)");
			System.out.print("Enter the Name: ");
			String name = sc.nextLine();
			pstmt.setString(1, name);
			System.out.print("Enter the email: ");
			String email = sc.nextLine();
			pstmt.setString(2, email);
			System.out.print("Enter the pass: ");
			String pass = sc.nextLine();
			pstmt.setString(3, pass);
			System.out.print("Enter the Phone no: ");
			long ph = sc.nextLong();
			pstmt.setLong(4, ph);

			k = pstmt.executeUpdate();

			return k;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
			return 0;
		}
	}

}
	
